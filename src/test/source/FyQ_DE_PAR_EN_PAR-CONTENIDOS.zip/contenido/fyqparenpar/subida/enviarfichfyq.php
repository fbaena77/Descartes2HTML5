<HTML><style type="text/css">
<!--
body {
	background-color: #CCFFFF;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<title>FyQ DE PAR EN PAR. PUBLICACI&Oacute;N DE FICHEROS</title><BODY>
  <h1 align="center"><strong><img src="atomo.png" width="30" height="25">&nbsp;&nbsp;&nbsp;FyQ DE PAR EN PAR. PUBLICACI&Oacute;N DE FICHEROS&nbsp;&nbsp; <img src="atomo.png" width="30" height="25"></strong></h1>
  <div align="center">
    <table width="80%"  border="1">
      <tr>
        <td><div align="center">Aquellos autores de ficheros de preguntas para el juego FyQ DE PAR EN PAR, deber&aacute;n enviar un correo al coordinador de Proyecto Newton, con los siguientes datos: </div></td>
      </tr>
      <tr>
        <td><div align="center">Direcci&oacute;n de correo:  jesus.manuel.munoz@roble.pntic.mec.es</div></td>
      </tr>
      <tr>
        <td><div align="center">Asunto: Env&iacute;o de fichero/s FyQ DE PAR EN PAR para su publicaci&oacute;n en la web de Newton </div></td>
      </tr>
      <tr>
        <td><div align="center">Mensaje: Nombre del autor/a, t&iacute;tulo/s de las bater&iacute;as de preguntas. Comentarios que el autor/a quiera realizar</div></td>
      </tr>
      <tr>
        <td><div align="center">Fichero/s adjunto/s: Fichero/s con las bater&iacute;as de preguntas que quieran ser publicadas. La extensi&oacute;n de los ficheros debe de ser txt y el tama&ntilde;o m&aacute;ximo de cada fichero 2 Mb </div></td>
      </tr>
    </table>
  </div>
  <p align="center">En el siguiente enlace se puede consultar el listado de ficheros publicados </p>
<p align="center">
  <input name="Submit" type="submit" onClick="MM_openBrWindow('listado.php','listado','scrollbars=yes,width=350,height=650')" value="Listado de ficheros publicados">
</p>
<h2 align="center"><strong><img src="atomo.png" width="30" height="25">&nbsp;UTILIZACI&Oacute;N DE FICHEROS EN EL ORDENADOR LOCAL <img src="atomo.png" width="30" height="25"></strong> </h2>
<div align="center">
  <table width="80%"  border="1">
    <tr>
      <td><div align="center">Descargar el juego completo desde la p&aacute;gina de Proyecto Newton al ordenador local, siguiendo las instrucciones de descarga que se indican en la web</div></td>
    </tr>
    <tr>
      <td><div align="center">Acceder a trav&eacute;s de la p&aacute;gina oficial de Proyecto Newton (on-line), generar el fichero del juego a trav&eacute;s del formulario y descargar el fichero .txt tal y como se indica en las instrucciones de generaci&oacute;n de ficheros</div></td>
    </tr>
    <tr>
      <td><div align="center">Copiar el fichero del juego .txt dentro de la carpeta del juego /subida/ficheros </div></td>
    </tr>
    <tr>
      <td><div align="center">Abrir el juego grabado en local. Ir al &uacute;ltimo punto del men&uacute; lateral izquierdo, donde aparece la versi&oacute;n del juego dise&ntilde;ado para introducir las preguntas a trav&eacute;s de ficheros</div></td>
    </tr>
    <tr>
      <td><div align="center">Abrir el juego e introducir el nombre del fichero (sin extensi&oacute;n) con cuyo contenido se desea jugar</div></td>
    </tr>
  </table>
</div>
<p align="center">&nbsp; </p>
</BODY>
</HTML>

