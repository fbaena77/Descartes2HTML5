<HTML><style type="text/css">
<!--
body {
	background-color: #CCFFFF;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_openBrWindow(theURL,winName,features) { //v2.0
  window.open(theURL,winName,features);
}
//-->
</script>
<title>FyQ DE PAR EN PAR. SUBIDA DE FICHEROS DE PREGUNTAS</title><BODY>
<FORM ENCTYPE="multipart/form-data" ACTION="sfich.php" METHOD="post"> 
  <h1 align="center"><strong><img src="atomo.png" width="30" height="25">&nbsp;&nbsp;&nbsp;FyQ PALABRAS CRUZADAS. SUBIDA DE FICHEROS DE  PREGUNTAS&nbsp;&nbsp; <img src="atomo.png" width="30" height="25"></strong></h1>
  <p align="justify">Subida de ficheros de texto de baterias de preguntas para el juego FyQ PALABRAS CRUZADAS. La extensi&oacute;n de los ficheros debe de ser txt y el tama&ntilde;o m&aacute;ximoi 10.000.000 bytes
    <INPUT type="hidden" name="lim_tamano" value="10000000">
  </p>
  <p align="center">Archivo a transferir (extensi&oacute;n txt) <br> 
    <INPUT type="file" name="archivo">
  </p>
  <p align="center"><INPUT type="submit" name="enviar" value="Aceptar"> 
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="reset" name="Submit" value="Borrar">
  </p>
</FORM>
<p align="center">&nbsp;</p>
<p align="center">
  <input name="Submit" type="submit" onClick="MM_openBrWindow('listado.php','listado','scrollbars=yes,width=350,height=650')" value="LISTADO DE FICHEROS YA CREADOS">
</p>
<p align="center">&nbsp; </p>
</BODY>
</HTML>

